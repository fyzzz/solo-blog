title: linux常用命令
date: '2019-07-04 15:10:38'
updated: '2019-07-11 11:18:54'
tags: [linux, 命令]
permalink: /articles/2019/07/04/1562224238441.html
---
![](https://img.hacpai.com/bing/20190423.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 0、查看linux系统位数
getconf LONG_BIT
### 1、获取root权限
sudo root  只有5分钟
su root然后输密码
### 2、修改root密码
sudo passwd root
### 3、:set nu  :set nonu
文本下添加行号和删除行号
### 4、/关键字  
文本下查询关键字，像windows里的ctrl+f
下一个  n
上一个 N
### 5、最末行  G  首行  gg
### 6、撤销   u
### 7、添加用户xm
useradd xm
passwd xm
### 8、删除用户
userdel xm  (家目录还在)
userdel -r xm  (家目录不在)
### 9、查询用户信息
id username
### 10、查询当前登录用户
whoami
### 11、创建目录
mkdir 单级目录
mkdir -p 多级目录
### 12、删除
rm 文件
rmdir 空目录
rm -rf 非空目录
-r ：递归删除整个文件夹
-f ： 强制删除不提示
### 13、创建一个空文件
touch 文件名（可以一次创建多个文件）
### 14、拷贝
拷贝单个文件：cp 源文件 目标文件或文件夹
递归拷贝目录：cp 源目录 目标目录下
加斜杠强制覆盖同名文件： \cp 源目录 目标目录下
### 15、mv 指令
mv oldNameFile newNameFile (功能描述：重命名)
mv /temp/movefile /targetFolder (功能描述：移动文件)
### 16、cat 指令
cat 查看文件内容，是以只读的方式打开。
cat -n[带行号] 文件名 | more [分页浏览，空格翻页]
### 17、less 指令
less 指令用来分屏查看文件内容，它的功能与 more 指令类似，但是比 more 指令更加强大，支持
各种显示终端。less 指令在显示文件内容时，并不是一次将整个文件加载之后才显示，而是根据显示
需要加载内容， 对于显示大型文件具有较高的效率。
•基本语法
less 要查看的文件
### 18、输出重定向和追加
介绍
\> 指令 和 >> 指令
\> 输出重定向 : 会将原来的文件的内容覆盖
\>> 追加： 不会覆盖原来文件的内容，而是追加到文件的尾部。
•基本语法
1) ls -l >文件 （功能描述：列表的内容写入文件 a.txt 中（覆盖写））
2) ls -al >>文件 （功能描述：列表的内容追加到文件 aa.txt 的末尾）
3) cat 文件 1 > 文件 2（功能描述：将文件 1 的内容覆盖到文件 2）
4) echo "内容" >> 文件
### 19、查看日历
cal
### 20、echo指令
echo 输出内容到控制台。
echo $PATH
### 21、head指令
head 用于显示文件的开头部分内容，默认情况下 head 指令显示文件的前 10 行内容
•基本语法
head 文件 (功能描述：查看文件头 10 行内容)
head -n 5 文件 (功能描述：查看文件头 5 行内容，5 可以是任意行数)
### 22、tail指令
tail 用于输出文件中尾部的内容，默认情况下 tail 指令显示文件的后 10 行内容。
•基本语法
1) tail 文件 （功能描述：查看文件后 10 行内容）
2) tail -n 5 文件 （功能描述：查看文件后 5 行内容，5 可以是任意行数）
3) tail -f 文件 （功能描述：实时追踪该文档的所有更新，工作经常使用）
### 23、ln指令
软链接也叫符号链接，类似于 windows 里的快捷方式，主要存放了链接其他文件的路径
•基本语法
ln -s [原文件或目录] [软链接名] （功能描述：给原文件创建一个软链接）
rm -rf 软连接
### 24、history 指令
查看已经执行过历史命令,也可以执行历史指令
•基本语法
history （功能描述：查看已经执行过历史命令）
显示最近使用过的 10 个指令。
history 10
执行历史编号为 5 的指令
!5
### 25、date 指令-显示当前日期
1) date （功能描述：显示当前时间）
2) date +%Y （功能描述：显示当前年份）
3) date +%m （功能描述：显示当前月份）
4) date +%d （功能描述：显示当前是哪一天）
5) date "+%Y-%m-%d %H:%M:%S"（功能描述：显示年月日时分秒）
设置时间
date -s  "2018-10-10 11:22:22"
### 26、find指令
find 指令将从指定目录向下递归地遍历其各个子目录，将满足条件的文件或者目录显示在终端。
•基本语法
find [搜索范围] [选项]
1: 按文件名：根据名称查找/home 目录下的 hello.txt 文件
find /home -name hello.txt
2:按拥有者：查找/opt 目录下，用户名称为 nobody 的文件
find /opt -user nobody
3:查找整个 linux 系统下大于 20m 的文件（+n 大于 -n 小于 n 等于）
find / -size +20M
### 27、locate 指令
locate 指令可以快速定位文件路径。
基本语法
locate 搜索文件
•特别说明
由于 locate 指令基于数据库进行查询，所以第一次运行前，必须使用 updatedb 指令创建 locate 数据库。
### 28、 grep 指令和 管道符号 |
grep 过滤查找 ， 管道符，“|”，表示将前一个命令的处理结果输出传递给后面的命令处理。
•基本语法
grep [选项] 查找内容 源文件
请在 hello.txt 文件中，查找 "yes" 所在行，并且显示行号
cat hello.txt | grep -n yes                         (区分大小写)
cat hello.txt | grep -ni yes			     (区分大小写)
### 29、压缩和解压缩
（1）gzip/gunzip 指令
gzip 文件 （功能描述：压缩文件，只能将文件压缩为*.gz 文件）
gunzip 文件.gz （功能描述：解压缩文件命令）
细节说明
当我们使用 gzip 对文件进行压缩后，不会保留原来的文件。
（2） zip/unzip 指令
zip 用于压缩文件， unzip 用于解压的，这个在项目打包发布中很有用的
•基本语法
zip [选项] XXX.zip 将要压缩的内容（功能描述：压缩文件和目录的命令）
unzip [选项] XXX.zip （功能描述：解压缩文件）
zip 常用选项
-r：递归压缩，即压缩目录
unzip 的常用选项
-d<目录> ：指定解压后文件的存放目录
案例 1: 将 /home 下的 所有文件进行压缩成 mypackage.zip
zip -r mypackage.zip /home
案例 2: 将 mypackge.zip 解压到 /opt/tmp 目录下
unzip -d /opt/tmp mypackage.zip
（3）tar指令
tar 指令  是打包指令，最后打包后的文件是 .tar.gz 的文件。
•基本语法
tar [选项] XXX.tar.gz 打包的内容 (功能描述：打包目录，压缩后的文件格式.tar.gz)
选项：
-c :产生.tar打包文件
-v :显示详细信息
-f :指定压缩后的文件名
-z :打包同时压缩
-x :解压.tar文件
案例 1: 压缩多个文件，将 /home/a1.txt 和 /home/a2.txt 压缩成 a.tar.gz
tar -zcvf a.tar.gz a1.txt a2.txt
案例 2: 将/home 的文件夹 压缩成 myhome.tar.gz
tar -zcvf myhome.tar.gz /home
案例 3: 将 a.tar.gz 解压到当前目录
tar -zxvf a.tar.gz
案例 4: 将 myhome.tar.gz 解压到 /opt/ 目录下
tar -zxvf myhome.tar.gz -C /opt
指定解压到的那个目录，事先要存在才能成功，否则会报错。
### 30、组管理

修改文件所有者：chown 用户名 文件名
修改文件所在的组： chgrp 组名 文件名
改变用户所在组
1) usermod –g 组名 用户名
2) usermod –d 目录名 用户名 改变该用户登陆的初始目录。
### 31、chmod指令
通过 chmod 指令，可以修改文件或者目录的权限
![HQF6AK33NI.png](https://img.hacpai.com/file/2019/07/HQF6AK33NI-6db04318.png)

u:所有者 g:所有组 o:其他人 a:所有人(u、g、o 的总和)
1) chmod u=rwx,g=rx,o=x 文件目录名
2) chmod o+w 文件目录名
3) chmod a-x 文件目录名
### 32、chown指令
基本介绍
chown newowner file 改变文件的所有者
chown newowner:newgroup file 改变用户的所有者和所有组
-R 如果是目录 则使其下所有子文件或目录递归生效
请将 /home/abc .txt 文件的所有者修改成 tom
chown tom /home/abc.txt
请将 /home/kkk 目录下所有的文件和目录的所有者都修改成 tom
chown -R tom /home/kkk
### 33、chgrp指令
基本介绍
chgrp newgroup file 改变文件的所有组
用法同chown
### 34、查看进程
ps -ef | grep 关键字
ps -aux | grep 关键字
### 35、终止进程
kill [选项] 进程号（功能描述：通过进程号杀死进程）
killall 进程名称（功能描述：通过进程名称杀死进程，也支持通配符，这在系统因负载过大而变
得很慢时很有用）
14.3.3 常用选项：
-9 :表示强迫进程立即停止
### 36、查看端口是否启用
[root@localhost ~]# lsof -i :6379
COMMAND    PID USER   FD   TYPE DEVICE SIZE/OFF NODE NAME
redis-ser 2382 root    6u  IPv4  17518      0t0  TCP localhost:6379 (LISTEN)
redis-ser 2382 root    7u  IPv4  17526      0t0  TCP localhost:6379->localhost:40083 (ESTABLISHED)
redis-cli 2386 root    3u  IPv4  17525      0t0  TCP localhost:40083->localhost:6379 (ESTABLISHED)

### 37、CentOS7防火墙操作
\# 开启
service firewalld start
\# 重启
service firewalld restart
\# 关闭
service firewalld stop

\# 查看防火墙规则
firewall-cmd --list-all 
查询、开放、关闭端口
\# 查询端口是否开放
firewall-cmd --query-port=8080/tcp
\# 开放80端口
firewall-cmd --permanent --add-port=80/tcp
\# 移除端口
firewall-cmd --permanent --remove-port=8080/tcp

#重启防火墙(修改配置后要重启防火墙)
firewall-cmd --reload











