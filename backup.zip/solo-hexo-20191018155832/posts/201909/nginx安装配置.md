title: nginx安装配置
date: '2019-09-17 09:08:34'
updated: '2019-09-17 19:39:59'
tags: [linux, nginx]
permalink: /articles/2019/09/17/1568682514403.html
---
### 安装命令
```
useradd -s /sbin/nologin -M nginx

./configure --prefix=/home/dwscmmp/software/nginx --user=www --group=www --with-http_stub_status_module --with-http_ssl_module

//安装pcre-devel解决问题  
yum -y install pcre-devel
yum -y install openssl openssl-devel

make
make install
```