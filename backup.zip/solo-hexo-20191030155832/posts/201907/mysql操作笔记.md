title: mysql操作笔记
date: '2019-07-11 10:48:54'
updated: '2019-09-19 11:40:50'
tags: [数据库, mysql]
permalink: /articles/2019/07/11/1562813334532.html
---
### 一、数据库管理

#### 1.1 初始化及开启远程访问
linux命令行输入：
`./bin/mysqld --initialize --user=mysql --basedir=/usr/local/env/mysql/mysql --datadir=/usr/local/env/mysql/mysql/data`
登录数据库后输入：
`use mysql;`
`grant  all  on *.* to  'root'@'%' identified by  'root用户的密码'  with  grant  option;`
检查：
`select user,host from user;`
#### 1.2 修改密码
第一次安装：`set password for 'root'@'localhost'=password('123');`
方法二：`alter user 'root'@'localhost' identified by  '123';`
#### 1.3 查看配置
1.3.1 查看数据文件路径
`show variables like "%datadir%";`

#### 1.4 复制
MySQL备份和还原,都是利用mysqldump、mysql和source命令来完成的。 
Windows下MySQL的备份与还原 
1.4.1 备份 
开始菜单 | 运行 | cmd |利用“cd /Program Files/MySQL/MySQL Server 5.0/bin”命令进入bin文件夹 | 利用“mysqldump  -u 用户名 -p databasename >exportfilename”导出数据库到文件，如mysqldump -u root -p voice>voice.sql，然后输入密码即可开始导出。 
1.4.2 还原 
进入MySQL Command Line Client，输入密码，进入到“mysql>”，输入命令"show databases；"，回车，看看有些什么数据库；建立你要还原的数据库，输入"create database voice；"，回车；切换到刚建立的数据库，输入"use voice；"，回车；导入数据，输入"source voice.sql；"，回车，开始导入，再次出现"mysql>"并且没有提示错误即还原成功。 
  
Linux下MySQL的备份与还原 
1.4.3 备份 
[root@localhost ~]# cd /var/lib/mysql (进入到MySQL库目录，根据自己的MySQL的安装情况调整目录) 
[root@localhost mysql]# mysqldump -u root -p voice>voice.sql，输入密码即可。
1.4.3 还原
方法一：
[root@localhost ~]# mysql -u root -p 回车，输入密码，进入MySQL的控制台"mysql>"，同1.34.2还原。
方法二：
[root@localhost ~]# cd /var/lib/mysql (进入到MySQL库目录，根据自己的MySQL的安装情况调整目录) 
[root@localhost mysql]# mysql -u root -p voice<voice.sql，输入密码即可。

#### 1.5 大小写敏感
linux下mysql安装完后是默认：区分表名的大小写，不区分列名的大小写；
用root帐号登录后，在/etc/my.cnf 中的[mysqld]后添加添加lower_case_table_names=1，重启MYSQL服务，这时已设置成功：不区分表名的大小写；

lower_case_table_names参数详解：

lower_case_table_names = 0

其中 0：区分大小写，1：不区分大小写

MySQL在Linux下数据库名、表名、列名、别名大小写规则是这样的：

　　 1、数据库名与表名是严格区分大小写的；

　　 2、表的别名是严格区分大小写的；

　　 3、列名与列的别名在所有的情况下均是忽略大小写的；

　　 4、变量名也是严格区分大小写的；
### 二、SQL
#### 2.1 IP和int的转换
--ip转int
`select inet_aton('73.115.134.73') as ip;`
--int转ip
`select inet_ntoa(1232307785) as ip;`
#### 2.2 日期函数
--获得当前时间
`now()`
`sysdate()`

--获得当前时间戳
`current_timestamp`
`current_timestamp()`

--时间转字符串
`select date_format(date, '%Y-%m-%d %H:%i:%s');`

--字符串转时间
`select str_to_date('2018-01-01 10:10:10', '%Y-%m-%d %H:%i:%s');`

--获得两个时间差
```
--秒
select TIMESTAMPDIFF( second , str_to_date('2019-01-01 00:00:00','%Y-%m-%d %H:%i:%s') , str_to_date('2019-01-01 00:03:00','%Y-%m-%d %H:%i:%s'))
--小时
select TIMESTAMPDIFF( hour , str_to_date('2019-01-01 00:00:00','%Y-%m-%d %H:%i:%s') , str_to_date('2019-01-01 00:03:00','%Y-%m-%d %H:%i:%s'))
```

#### 2.3 复制表结构
```
CREATE [TEMPORARY] TABLE [IF NOT EXISTS] tbl_name
    { LIKE old_tbl_name | (LIKE old_tbl_name) };
--如：
CREATE  TABLE IF NOT EXISTS tb_base_like (LIKE tb_base); 
```