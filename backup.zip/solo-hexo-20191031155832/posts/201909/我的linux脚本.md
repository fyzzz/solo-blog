title: 我的linux脚本
date: '2019-09-21 15:31:21'
updated: '2019-09-23 10:05:47'
tags: [linux]
permalink: /articles/2019/09/21/1569051081415.html
---
![](https://img.hacpai.com/bing/20180328.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 1、备份数据库
```
if [ $# -lt 1 ]
then
 database=test
else
 database=$1
fi
echo $database
/usr/local/mysql/bin/mysqldump -uroot -p $database > ./$database'.sql'
```
### 2、启动SpringBoot项目
```
nohup java -jar xxx.jar &
pid=`ps -ef|grep xxx.jar|grep -v grep|awk '{print $2}'`
echo $pid
```
### 3、停止SpringBoot项目
```
pid=`ps -ef|grep dwscmmp-0.0.1-SNAPSHOT.jar|grep -v grep|awk '{print $2}'`
echo $pid
for id in $pid
do
    kill -9 $id
    echo "kill -9 $id"
done
```