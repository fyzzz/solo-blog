title: SpringBoot通过systemctl自启动
date: '2019-09-16 11:16:47'
updated: '2019-09-16 11:16:47'
tags: [springboot, linux]
permalink: /articles/2019/09/16/1568603807659.html
---
```
[Unit]

Description=a
After=syslog.target mysqld.service

[Install]
WantedBy=multi-user.target

[Service]
WorkingDirectory=/home/test/boot/a
User=test
Group=test
Type=simple

# Start main service
ExecStart=/usr/local/env/java/jdk1.8.0_171/bin/java -jar /home/test/boot/a/a.jar
# EnvironmentFile=/home/test/boot/a/application.yml
ExecStop=kill $MAINPID
#Restart=always

```