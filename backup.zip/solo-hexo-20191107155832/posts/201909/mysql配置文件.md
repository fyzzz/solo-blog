title: mysql配置文件
date: '2019-09-10 11:40:29'
updated: '2019-09-10 11:40:29'
tags: [mysql]
permalink: /articles/2019/09/10/1568086828965.html
---
#### mysql配置文件备份
```
# For advice on how to change settings please see

# http://dev.mysql.com/doc/refman/5.7/en/server-configuration-defaults.html
 
[mysqld]
#
#skip-grant-tables
# Remove leading # and set to the amount of RAM for the most important data
# cache in MySQL. Start at 70% of total RAM for dedicated server, else 10%.
innodb_buffer_pool_size=1G
lower_case_table_names=0
#
# Remove leading # to turn on a very important data integrity option: logging
# changes to the binary log between backups.
# log_bin
#
# Remove leading # to set options mainly useful for reporting servers.
# The server defaults are faster for transactions and fast SELECTs.
# Adjust sizes as needed, experiment to find the optimal values.
# join_buffer_size = 128M
# sort_buffer_size = 2M
# read_rnd_buffer_size = 2M
datadir=/usr/local/mysql/data
socket=/var/lib/mysqld/mysql.sock
character-set-server=utf8mb4
# Disabling symbolic-links is recommended to prevent assorted security risks
symbolic-links=0
sql_mode=STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION
 
log-error=/var/log/mysqld.log
pid-file=/var/run/mysqld/mysqld.pid
server-id=1
log-bin=mysql-bin
log-slave-updates=1
default-storage-engine=INNODB
innodb_large_prefix=on
max_connections = 2000
max_connect_errors=2000
 
#skip-grant-tables
#
[client]
default-character-set=utf8
socket=/var/lib/mysqld/mysql.sock

[mysql]
default-character-set=utf8
socket=/var/lib/mysqld/mysql.sock

```