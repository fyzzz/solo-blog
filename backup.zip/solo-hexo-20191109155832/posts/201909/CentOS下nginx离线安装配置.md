title: CentOS下nginx离线安装配置
date: '2019-09-17 09:08:34'
updated: '2019-11-05 11:15:09'
tags: [linux, nginx]
permalink: /articles/2019/09/17/1568682514403.html
---
![](https://img.hacpai.com/bing/20190916.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 1、前提条件
检查是否有gcc和g++命令
```
gcc --version
g++ --version
# 如果没有，在线安装命令：
yum install gcc
yum install gcc gcc-c++
# 离线情况找离线安装包安装。
```
### 2、准备文件
nginx-xxx.tar.gz，[下载地址](http://nginx.org/en/download.html)
zlib-xxx.tar.gz，[下载地址](https://www.zlib.net/)
pcre-xxx.tar.gz [下载地址](https://sourceforge.net/projects/pcre/files/pcre/)
openssl-xxx.tar.gz [下载地址](https://www.openssl.org/source/)
### 3、源码编译
把上述四个文件上传到`/usr/local/src`目录。
![image.png](https://img.hacpai.com/file/2019/11/image-3ce9a7cd.png)

#### 安装openssl（以1.0.2t版本为例）
```
# 进入目录
cd /usr/local/src
# 解压
tar -zxvf openssl-1.0.2t.tar.gz  -C /usr/local
# 进入解压目录 
cd /usr/local/openssl-1.0.2t
# 配置
./config
# 编译安装（需要几分钟）
make && make install
```
#### 安装pcre（以8.43版本为例）
```
# 进入目录
cd /usr/local/src
# 解压
tar -zxvf pcre-8.43.tar.gz -C /usr/local
# 进入解压目录 
cd /usr/local/pcre-8.43
# 配置
./configure
# 编译安装
make && make install
```
#### 安装zlib（以1.2.11版本为例）
```
# 进入目录
cd /usr/local/src
# 解压
tar -zxvf zlib-1.2.11.tar.gz  -C /usr/local
# 进入解压目录 
cd /usr/local/zlib-1.2.11
# 配置
./configure
# 编译安装
make && make install
```
#### 安装nginx（以1.16.1版本为例）
```
# 创建nginx用户
useradd -s /sbin/nologin -M nginx
# 进入目录
cd /usr/local/src
# 解压
tar -zxvf nginx-1.16.1.tar.gz 
# 进入解压目录 
cd nginx-1.16.1
# 配置
./configure --prefix=/usr/local/nginx --user=nginx --group=nginx --with-http_ssl_module --with-pcre=/usr/local/pcre-8.43 --with-zlib=/usr/local/zlib-1.2.11 --with-openssl=/usr/local/openssl-1.0.2t
# 编译安装（需要几分钟）
make && make install
# 创建软连接
ln -s /usr/local/nginx/sbin/nginx /usr/bin/nginx
```
