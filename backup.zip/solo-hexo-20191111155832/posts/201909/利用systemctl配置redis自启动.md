title: 利用systemctl配置redis自启动
date: '2019-09-09 16:09:09'
updated: '2019-11-01 16:01:35'
tags: [linux, redis]
permalink: /articles/2019/09/09/1568016549240.html
---
![](https://img.hacpai.com/bing/20190802.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 1、安装
1、到官网下载最新版redis，[中文官网](https://www.redis.net.cn/)，本文使用5.0.4版。
2、把下载的redis-5.0.4.tar.gz移动到/usr/local/src目录下，解压。
3、解压后如图：
![image.png](https://img.hacpai.com/file/2019/09/image-611f3c01.png)
4、执行
`cd /usr/local/src/redis-5.0.4`
`make`
`make PREFIX=/usr/local/redis install`
`cp /usr/local/src/redis-5.0.4/redis.conf /usr/local/redis/redis.conf`
安装后如图
![image.png](https://img.hacpai.com/file/2019/09/image-c3b7494c.png)

### 2、修改配置文件
配置文件位置：`/usr/local/redis/redis.conf`
修改如下几项：
1、bind 127.0.0.1 注释掉，可以让redis远程连接
2、protected-mode yes  改为no，关闭保护模式，没有指定bind也可以连接。
3、port 6379 按需修改启动端口
4、daemonize no 改为yes，后台运行(使用systemctl时需要配置为：no)
5、logfile "" 按需修改日志位置
6、# requirepass foobared  把'#'去掉， foobared改成自定义密码。

### 3、设置开机自启
在`/etc/systemd/system`下新建redisd.service文件
内容如下
```
# redis启动文件

[Unit]
Description=redis
After=network.target
After=syslog.target

[Install]
WantedBy=multi-user.target

[Service]

Type=simple

# Disable service start and stop timeout logic of systemd for redis service.
TimeoutSec=0

# Start main service
ExecStart=/usr/local/redis/bin/redis-server /usr/local/redis/redis.conf

# Sets open_files_limit
LimitNOFILE = 5000

Restart=on-failure

RestartPreventExitStatus=1

PrivateTmp=false
```
执行`systemctl enable redisd`即可开机自启。
执行`systemctl status redisd`，检查状态
![image.png](https://img.hacpai.com/file/2019/09/image-00601699.png)



