title: JAVA正则表达式api
date: '2019-06-17 16:31:20'
updated: '2019-06-19 19:05:16'
tags: [正则表达式]
permalink: /articles/2019/06/17/1560760280633.html
---
Java 提供了功能强大的正则表达式API，在java.util.regex 包下。整理一点常用的api。

[正则表达式可视化](https://regexper.com/)
# Pattern
正则表达式经编译后的表现模式，必须先将正则表达式（字符串形式）编译成此实例。
### 获取Pattern实例
构造器是私有的，可通过如下方法获取实例：
```
Pattern pattern = Pattern.compile("\\d");
```
# Matcher
匹配器，一个Matcher对象可以匹配任意character sequences。
### 获取Matcher实例
```
String str = "12";
Pattern pattern = Pattern.compile("\\d{2}");
Matcher matcher = pattern.matcher(str);
```
### 匹配全部字符串
```
String str = "12";
System.out.println("----方法1----");
Pattern pattern = Pattern.compile("\\d{2}");
Matcher matcher = pattern.matcher(str);
System.out.println(matcher.matches());
System.out.println("----方法2----");
System.out.println(Pattern.matches("\\d{2}",str));
```
输出
```
----方法1----
true
----方法2----
true
```
### 匹配部分字符串
判断字符串是否包含符合正则表达式的字符串
```
String str = "This is Hangzhou";
Pattern pattern = Pattern.compile("Hangzhou");
Matcher matcher = pattern.matcher(str);
//判断是否包含
System.out.println(matcher.find());
//输出第一个符合的字符串
System.out.println(matcher.group());
```
find()方法，每次调用都返回下一个
如下输出所有匹配的字符串
start() ：开始位置
end()：结束位置+1
```
String str = "#ffbbad asda #f33 #ffdd11 #dsasaa ";
Pattern pattern = Pattern.compile("#[a-fA-F0-9]{6}|#[a-fA-F0-9]{3}");
Matcher matcher = pattern.matcher(str);
while(matcher.find()){
	System.out.println(matcher.group()+" start:"+matcher.start()+",end:"+matcher.end());
}
```
结果：
```
#ffbbad start:0,end:7
#f33 start:13,end:17
#ffdd11 start:18,end:25
```

