title: redis常用命令
date: '2019-06-18 17:25:03'
updated: '2019-06-18 17:25:03'
tags: [数据库, redis]
permalink: /articles/2019/06/18/1560849902928.html
---
[http://redisdoc.com/](http://redisdoc.com/)

1、启动，后面的配置文件，可不选用默认的

```
redis-server /root/mybackup/redis.conf
```
2、检查启动是否成功
```
[root@localhost bin]# redis-cli -p 6379
127.0.0.1:6379> ping
```
出现以下单词即成功
```
PONG
```
3、输入输出
```
127.0.0.1:6379> set k1 hello
OK
127.0.0.1:6379> get k1
"hello"
```
4、关闭
```
127.0.0.1:6379> shutdown
not connected> exit
```
5、查看有多少数据
```
DBSIZE
```
6、查看具体所有的数据，redis单线程，会造成阻塞
```
keys *
```
7、清库

`FLUSHALL` 清所有库
`FLUSHDB `清当前库

8、移动数据到别的库
````
move k1 2
````
9、为指定的key设置过期时间
```
expire key 秒钟
```
10、查看还有多少秒过期，-1表示永不过期，-2表示已过期
```
ttl key
```
11、查看key是什么类型
```
type key
```
12、删除key
```
DEL key
```
13、追加和获取字符串长度
```
append key str
strlen key
```

14、Incr/decr/incrby/decrby，一定要是数字才能加减

`Incr key `    递增1
`Incrby key 2`    递增2

15、getrange

```
127.0.0.1:6379> get k1
"zfy12345"
127.0.0.1:6379> GETRANGE k1 0 -1
"zfy12345"
127.0.0.1:6379> GETRANGE k1 0 3
"zfy1"
```

16、setrange

```
127.0.0.1:6379> get k1
"zfy123451hhh"
127.0.0.1:6379> SETRANGE k1 0 aaa
(integer) 12
127.0.0.1:6379> get k1
"aaa123451hhh"
```

17、setex（set with expire）赋值时设置过期时间
```
127.0.0.1:6379> setex k4 10 v4
OK
127.0.0.1:6379> ttl k4
(integer) 8
127.0.0.1:6379>
```
18、setnx（set if not exist）

添加时，如果存在，则不覆盖

19、mset/mget/msetnx

```
127.0.0.1:6379> mset k1 v1 k2 v2 k3 v3
OK
127.0.0.1:6379> mget k1 k2 k3
1) "v1"
2) "v2"
3) "v3"
```

msetnx有一个失败就都失败

```
127.0.0.1:6379> msetnx k1 v11 k4 v4
(integer) 0
127.0.0.1:6379> mget k1 k4
1) "v1"
2) (nil)
127.0.0.1:6379>
```

20、save/bgsave

立刻备份

`save`：只保存，会阻塞

`bgsave`：异步操作，不会阻塞

21、修复aof文件

```
redis-check-aof --fix xxx.aof
```