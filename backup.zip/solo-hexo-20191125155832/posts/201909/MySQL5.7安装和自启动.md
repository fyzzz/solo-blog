title: MySQL5.7安装和自启动
date: '2019-09-10 17:30:55'
updated: '2019-11-01 13:51:34'
tags: [mysql, linux]
permalink: /articles/2019/09/10/1568107855050.html
---
![](https://img.hacpai.com/bing/20181125.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 准备
MySQL安装包：mysql-5.7.26-linux-glibc2.12-x86_64.tar.gz
### 安装
1、新建目录：`/usr/local/mysql`
2、把安装包解压到上述目录
解压命令：`tar -zxvf mysql-5.7.26-linux-glibc2.12-x86_64.tar.gz -C /usr/local/mysql`
3、把配置文件移到`/etc`目录下，[点击获取配置文件](http://fyzzz.cn/articles/2019/09/10/1568086828965.html)
4、新建目录：`/var/lib/mysqld`,`/var/run/mysqld`,`/usr/local/mysql/data`
5、新建文件：`/var/log/mysqld.log`
6、新建mysql用户
```
groupadd mysql
useradd -r -g mysql mysql
# -r表示这个用户是系统用户，不能登录。
# -g表示分组
```
7、把之前建的文件和目录都归属`mysql`用户所有
命令：`chown mysql:mysql  目录...`
8、初始化，移到`/usr/local/mysql`目录
执行：
```
./bin/mysqld --initialize --user=mysql --basedir=/usr/local/mysql --datadir=/usr/local/mysql/data
```
9、在`/var/log/mysqld.log`中找到初始化密码
![image.png](https://img.hacpai.com/file/2019/09/image-145cb27f.png)
10、执行`/usr/local/mysql/support-files/mysql.server start`启动服务
11、执行`/usr/local/mysql/bin/mysql -uroot -p`，回车输入初始号密码。
12、修改密码，开放远程连接
```
set password for 'root'@'localhost'=password('你的密码');
use mysql;
grant all on *.* to 'root'@'%' identified by 'root用户的密码' with grant option;
#检查： 
select user,host from user;
```
### 自启动
1、新建文件`/etc/systemd/system/mysqld.service`
2、填入以下内容
```
# Copyright (c) 2015, 2016, Oracle and/or its affiliates. All rights reserved.

#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2 of the License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
#
# systemd service file for MySQL forking server
#

[Unit]
Description=MySQL Server
Documentation=man:mysqld(8)
Documentation=http://dev.mysql.com/doc/refman/en/using-systemd.html
After=network.target
After=syslog.target

[Install]
WantedBy=multi-user.target

[Service]
User=mysql
Group=mysql

Type=forking

PIDFile=/var/run/mysqld/mysqld.pid

# Disable service start and stop timeout logic of systemd for mysqld service.
TimeoutSec=0

# Execute pre and post scripts as root
PermissionsStartOnly=true

# Needed to create system tables
# ExecStartPre=/usr/bin/mysqld_pre_systemd

# Start main service
ExecStart=/usr/local/mysql/support-files/mysql.server start

# Use this to switch malloc implementation
EnvironmentFile=-/etc/sysconfig/mysql

# Sets open_files_limit
LimitNOFILE = 5000

Restart=on-failure

RestartPreventExitStatus=1

PrivateTmp=false
```
执行 `systemctl enable mysqld`即可自启动。
检查：`systemctl status mysqld`
